-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2019 at 09:29 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mobile`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `categoryid` int(11) NOT NULL,
  `catname` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`categoryid`, `catname`) VALUES
(4, 'ONE PLUS'),
(5, 'SAMSUNG'),
(6, 'REALME'),
(7, 'REDMI'),
(9, 'MOTOROLA'),
(10, 'IPHONE');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productid` int(11) NOT NULL,
  `categoryid` int(1) NOT NULL,
  `productname` varchar(30) NOT NULL,
  `price` double NOT NULL,
  `photo` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productid`, `categoryid`, `productname`, `price`, `photo`) VALUES
(15, 4, 'ONE PLUS 6T', 29000, 'upload/6t_1575210017.jpg'),
(16, 5, 'GALAXY 7', 25000, 'upload/S1_1575211403.jpg'),
(17, 5, 'GALAXY M', 40000, 'upload/S2_1575211477.jpg'),
(19, 7, 'NOTE 8 PRO', 19000, 'upload/redmii_1575211083.jfif'),
(20, 6, 'XT', 45000, 'upload/realxt_1575210186.jfif'),
(21, 4, 'ONE PLUS 7T', 39000, 'upload/one plus 7_1575210088.jpg'),
(22, 4, 'ONE PLUS T', 15000, 'upload/t_1575210130.jpg'),
(23, 6, 'NOVA', 28000, 'upload/hnova_1575211134.jfif'),
(24, 6, 'R PRO', 15000, 'upload/real_1575210226.jfif'),
(26, 9, '3RD GEN', 15000, 'upload/moto_1575211002.jfif'),
(27, 10, 'X', 85000, 'upload/I1_1575211565.jpg'),
(28, 7, 'NOTE 7 PRO', 14000, 'upload/S2_1575211477_1575456539.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `purchaseid` int(11) NOT NULL,
  `customer` varchar(50) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `mob` varchar(255) NOT NULL,
  `total` double NOT NULL,
  `date_purchase` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`purchaseid`, `customer`, `Email`, `mob`, `total`, `date_purchase`) VALUES
(21, 'deepa', 'deepa@gmail.com', '7896541230', 117000, '2019-12-04 15:59:33'),
(22, 'deepaa', 'poojarideepa@gmail.com', '9632694546', 60000, '2019-12-04 16:10:05'),
(23, 'imran1', 'imranmohd697@gmail.com', '9632694546', 59000, '2019-12-04 16:15:41');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_detail`
--

CREATE TABLE `purchase_detail` (
  `pdid` int(11) NOT NULL,
  `purchaseid` int(11) NOT NULL,
  `productid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_detail`
--

INSERT INTO `purchase_detail` (`pdid`, `purchaseid`, `productid`, `quantity`) VALUES
(13, 8, 15, 2),
(14, 8, 17, 2),
(15, 8, 18, 2),
(16, 9, 15, 3),
(17, 10, 15, 1),
(18, 10, 23, 1),
(19, 11, 21, 1),
(20, 11, 22, 1),
(21, 12, 21, 1),
(22, 12, 22, 1),
(23, 13, 20, 1),
(24, 13, 27, 2),
(25, 14, 21, 1),
(26, 15, 21, 1),
(27, 16, 27, 1),
(28, 17, 27, 1),
(29, 18, 17, 1),
(30, 19, 19, 1),
(31, 20, 20, 1),
(32, 21, 15, 3),
(33, 21, 22, 2),
(34, 22, 20, 1),
(35, 22, 26, 1),
(36, 23, 15, 1),
(37, 23, 22, 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(4, 'user', 'user@gmail.com', '123'),
(5, 'deepa', 'poojarydeepa370@gmail.com', '321');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`categoryid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productid`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`purchaseid`);

--
-- Indexes for table `purchase_detail`
--
ALTER TABLE `purchase_detail`
  ADD PRIMARY KEY (`pdid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `categoryid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `productid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `purchase`
--
ALTER TABLE `purchase`
  MODIFY `purchaseid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `purchase_detail`
--
ALTER TABLE `purchase_detail`
  MODIFY `pdid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
