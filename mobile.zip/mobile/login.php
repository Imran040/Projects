<?php
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<link rel="stylesheet" href="css/style.css" />
      <style type="text/css">
body
{
background-image:url('img/b2.jfif');
      height: 100%;
       background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
</style>

</head>
<body>
      
      
<?php
	require('conn.php');
	session_start();
    // If form submitted, insert values into the database.
    if (isset($_POST['username'])){
		
		//$username = stripslashes($_REQUEST['username']);// removes backslashes
          $username = ($_REQUEST['username']);
		$username = mysqli_real_escape_string($conn,$username); //escapes special characters in a string
		//$password = stripslashes($_REQUEST['password']);
          $password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($conn,$password);
		
	//Checking is user existing in the database or not
        $query = "SELECT * FROM `users` WHERE username='$username' and password='$password'";
		$result = mysqli_query($conn,$query) or die(mysqli_error());
		$rows = mysqli_num_rows($result);
        if($rows==1){
			$_SESSION['username'] = $username;
			header("Location: index.php"); // Redirect user to index.php
            }else{
				echo "<div class='form'><h3>Username/password is incorrect.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
				}
    }else{
?>
       <h1><center>MOBILE SALES MANAGEMENT</center></h1>
<div class="form">
     
<h2><center>Log In</center></h2>

<form action="" method="post" name="login">
<input type="text" name="username" placeholder="Username" required />
<input type="password" name="password" placeholder="Password" required />
<input name="submit" type="submit" value="Login" />
</form>
<p>Not registered yet? <a href='registration.php'><b>Register Here</b></a></p>

<br /><br />

</div>
<?php } ?>


</body>
</html>
